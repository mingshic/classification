import math

def ComputeEuclideanDistance(x1,y1,x2,y2):
    d = math.sqrt(math.pow((x1 - x2), 2) + math.pow((y1 - y2), 2))
    return d

d_expa = ComputeEuclideanDistance(3,104,18,90)
d_expb = ComputeEuclideanDistance(2,100,18,90)
d_expc = ComputeEuclideanDistance(1,81,18,90)
d_expd = ComputeEuclideanDistance(101,10,18,90)
d_expe = ComputeEuclideanDistance(99,5,18,90)
d_expf = ComputeEuclideanDistance(98,2,18,90)

print "d_expa: ", d_expa
print "d_expb: ", d_expb
print "d_expc: ", d_expc
print "d_expd: ", d_expd
print "d_expe: ", d_expe
print "d_expf: ", d_expf
