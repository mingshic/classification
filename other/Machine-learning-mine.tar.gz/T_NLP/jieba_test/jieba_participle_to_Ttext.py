import sys
import os
import jieba

reload(sys)
sys.setdefaultencoding('utf-8')
wordlists = []

sent = open('Ttext')
word = jieba.cut(sent.read()) 
wordlist = "|".join(word)
wordlists = wordlist.split('|')
#for i in range(len(wordlists)):
#    if wordlists[i] is None:
#        continue
#    else:
#        print wordlists[i]
print wordlist


