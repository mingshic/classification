import sys
import os
import jieba
import jieba.analyse

reload(sys)
sys.setdefaultencoding('utf8')
#wordlists = []

content = open('XTtext.txt')
#word = jieba.cut(sent.read()) 
keywords = jieba.analyse.extract_tags(content.read(), topK=10000, withWeight=True, allowPOS=())
#wordlist = "|".join(word)
#wordlists = wordlist.split('|')
#for i in range(len(wordlists)):
#    if wordlists[i] is '':
#        continue
#    else:
#        print wordlists[i]
#print wordlist
#print wordlists
for item in keywords:
    print item[0], item[1]

