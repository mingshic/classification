#-*- coding: utf-8 -*-

import jieba  
f1 =open("XTtext.txt")  
f2 =open("XTtext_result.txt", 'a')  
lines =f1.readlines()
print lines
for line in lines:  
    line.replace('\t', '').replace('\n', '').replace(' ','')  
    seg_list = jieba.cut(line)  
    f2.write(" ".join(seg_list))  
   
f1.close()  
f2.close()
