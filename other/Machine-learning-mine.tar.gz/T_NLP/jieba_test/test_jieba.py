#-*- coding: utf-8 -*-

import sys
import os
import jieba

reload(sys)
sys.setdefaultencoding('utf-8')
wordlists = []

#jieba.load_userdict("dict_rule")
sent1 = "所有事物的无论微宏观角度，都有着一定的关联性，微宏观联系的创造是意想不到的。"
sent2 = "在包含问题的所有解的解空间树中，按照深度优化搜索的策略，从根节点出发深度探索解空间树。"
word1 = jieba.cut(sent1) 
word2 = jieba.cut(sent2) 
wordlist1 = "|".join(word1)
wordlist2 = "|".join(word2)
#wordlists = wordlist1.split('|')
#wordlists = wordlist2.split('|')
print wordlist1
print wordlist2
