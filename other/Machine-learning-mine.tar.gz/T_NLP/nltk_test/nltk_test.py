import sys
import os
#import nltk
from stanford import StanfordPOSTagger

reload(sys)
sys.setdefaultencoding('utf-8')

root = 
nltk.download()
