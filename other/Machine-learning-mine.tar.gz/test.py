import matplotlib.pyplot as plt  
import time
X1 = range(0, 50)  
Y1 = [num**2 for num in X1]
  
Fig = plt.figure(figsize=(8,4)) 
Ax = Fig.add_subplot(111)
Ax.plot(X1, Y1)#, X2, Y2)
  
Fig.show() 
time.sleep(3)  
Fig.savefig("test.pdf")
