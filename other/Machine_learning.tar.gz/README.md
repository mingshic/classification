Machine-Learning-With-Python
========================
此项目是我在学习《机器学习实战》这本书时的代码记录情况，用python实现，当然也会包括一些其他的机器学习

0: 【距离计算】MachingLearning中的距离和相似性计算以及python实现:<br/>
http://blog.csdn.net/gamer_gyt/article/details/75165842 <br/>

1：【关联规则】Apriori算法分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51113753 <br/>

2：【关联规则】FP-Tree算法分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51113753 <br/>

3：【决策树算法】基于信息论的三种决策树算法之ID3算法分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51242815<br/>

4：【聚类算法】二分-kMeans算法（二分K均值聚类）分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/48949227<br/>

5：【回归算法】Logistic回归算法分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51236978<br/>
http://blog.csdn.net/gamer_gyt/article/details/51242150<br/>

6：【分类算法】AdaBoost算法分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51372309<br/>

7：【分类算法】朴素贝叶斯算法分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/47205371<br/>
http://blog.csdn.net/gamer_gyt/article/details/47860945<br/>

8：【回归算法】预测数值型数据-回归（Regression）分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51405251<br/>

9：【降维技术】PCA降维技术分析与Python代码实现，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51418069<br/>

10：【推荐系统】基于标签的推荐系统，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51684716<br/>

11：【推荐系统】基于图推荐系统，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51694250<br/>

12：【推荐系统】基于用户和Item的协同过滤推荐算法，具体分析请参考博客：<br/>
http://blog.csdn.net/gamer_gyt/article/details/51346159<br/>

13：基于随机变量的熵来进行数据建模和分析<br/>
http://blog.csdn.net/gamer_gyt/article/details/53729868<br/>

14：推荐算法的回顾总结<br/>
http://blog.csdn.net/gamer_gyt/article/details/74367714<br/>

--------------------------
# 数据采集样例代码
文件夹为 spider，其内会逐步增加一些爬虫程序和数据，希望对你们有帮助

<br/><br/>CSDN博客地址：<br/>
http://blog.csdn.net/gamer_gyt/<br/>

如有问题请联系：<br/>
QQ：1923361654<br/>
WeChat：gyt13342445911<br/>
Email：thinkgamer_gyt@gmail.com<br/>
