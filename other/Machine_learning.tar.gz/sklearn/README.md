0:  line_regression——回归分析之Sklearn实现电力预测<br>
http://blog.csdn.net/Gamer_gyt/article/details/78467021<br>
