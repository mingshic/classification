#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
@author: nl8590687
语音识别的语言模型

尚未完成
"""



class ModelLanguage(): # 语音模型类
	def __init__(self):
		pass
		
	def LoadModel(self):
		pass
		
	def decode(self,list_syllable):
		pass



if(__name__=='__main__'):
	
	ml = ModelLanguage()
	

