CNN
文本分类
