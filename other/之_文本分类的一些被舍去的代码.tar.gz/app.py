#!/usr/bin/env python

import os
import sys
from flask import Flask, jsonify, abort, request, make_response
import json
import urllib.request
#import urllib2
import codecs
import simplejson


from predict_contract_cnn import CnnModel

app = Flask(__name__)
#app.config.update(RESTFUL_JSON=dict(ensure_ascii=False))
app.config['JSON_AS_ASCII'] = False



def writeFile(way,content,open_file):
    if way == "type":
        with open(open_file, "wb") as code:
            code.write(content) 
    elif way == "txt":
        with open(open_file, "w") as code:
            code.write(content)    


def predict_command(open_file):
    response = list(os.popen("python predict_contract_cnn.py %s" % open_file))[0].strip()
    return response


@app.route('/api/word', methods=['GET', 'POST'])
def gain_info():
    if request.method == 'POST':
        data = request.data
        data = json.loads(data.decode('utf8'))
        try:
            if data['request_type'] != '':
                try:
                    value = data['request_type']
                    url_endswith = value.split(".")[-1]
                    f = urllib.request.urlopen(value)
                   # f = urllib2.urlopen(value)
                    url_file_content = f.read()
                    open_file = "predict_files" + '/' + "file"+'.'+url_endswith
                    writeFile("type", url_file_content, open_file)
                except:
                    return make_response(jsonify({"error": "The key's value of 'request_type' is not correct, please check your value(url)"}), 404) 
#                contract_predict = CnnModel()
#                return jsonify(contract_predict.predict("url", open_file))
#                return jsonify(predict("url", open_file))
                return jsonify({"code": 1, "data": predict_command(open_file)})
        except:
            return make_response(jsonify({"error": "The key 'request_type' was missing, please check your 'request_type' field"}), 404)

        try:
            if data['request_data'] != '':
                value = data['request_data']
                text_content = value
                open_file = "predict_files" + '/' + "file" + '.' + 'txt'
                writeFile("txt", text_content, open_file)
                return jsonify({"type": predict_command(open_file)})
#                contract_predict = CnnModel()
#                return jsonify(contract_predict.predict("txt", open_file))
        except:
            return make_response(jsonify({"error": "The key 'request_data' was missing, please check your 'request_data' field"}), 404)
                        
    return jsonify({"response": "no data"})    

#@app.errorhandler(404)
#def not_found(error):
#    return make_response(jsonify({'error': 'Not found'}), 404)

if __name__=='__main__':
    app.run(debug=True,host="0.0.0.0",port=5000)
