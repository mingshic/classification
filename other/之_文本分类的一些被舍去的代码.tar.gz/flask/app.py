#!/usr/bin/env python

import sys
from flask import Flask, jsonify, abort, request, make_response
import json
import urllib.request

sys.path.append("..")
from predict_contract_cnn import CnnModel

app = Flask(__name__)

def writeFile(content,open_file):
    with open(open_file, "wb") as code:
        code.write(content)     

@app.route('/api/word', methods=['GET', 'POST'])
def gain_info():
    if request.method == 'POST':
        data = request.data
        data = json.loads(data.decode('utf8'))
        if len(list(data.keys())) == 1:
            value = list(data.values())[0]
          #  try:
            if value.split("://")[0] == "http":   
                url_endswith = value.split(".")[-1]
                f = urllib.request.urlopen(value)
          # url_endswith = or != docx
                url_file_content = f.read()
                open_file = "file"+'.'+url_endswith
                writeFile(url_file_content, open_file)
                print (open_file)
                contract_predict = CnnModel()
                print (222)
                print (contract_predict.predict(open_file))
         #   except:
         #       pass
            try:
                if value.split("://")[0] != "http":
                    text_content = value
                    open_file = "file"+'.'+'docx'
                    writeFile(text_content, open_file)
                    print (1)
                    contract_predict = CnnModel()
                    print (contract_predict.predict(open_file))
            except:
                pass
                        
    return jsonify("yes")    

#@app.errorhandler(404)
#def not_found(error):
#    return make_response(jsonify({'error': 'Not found'}), 404)

if __name__=='__main__':
    app.run(debug=True,host="0.0.0.0",port=5000)
